<footer id="footer-site" class="bg-oscuro">
    <div class="container-fluid wrap">
        <div class="row contenedor-footer">
            <div class="texto-footer-site col-md-auto">
                <p>Las Esteras Norte 2601, Quilicura</p>
                <p><a href="tel:+56999159535"><img src="images/ic-buss.png" alt="" width="20"> +56 9 9915 9535</a></p>
            </div>
            <div class="logo-footer col-md-auto">
                <a href="index.php" class="logo">
                    <img src="images/logo.svg" alt="EcoPark Center" title="EcoPark Center">
                </a>
            </div>
        </div>
    </div>
</footer>