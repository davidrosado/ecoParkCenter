    <div id="formulario-home" class="contenedor-formulario col-md-4">
        <div  class="formulario-cotizar">
          <h2>ARRIENDO DE BODEGAS<br>
          <span>DESDE 350 A 490 M2</span></h2>
          <form id="form-cotizar" method="POST" href="#">
            <div class="form-group">
              <label>Nombre y Apellido</label>
              <input type="text" id="field_nombre" name="field_nombre" required="required" autocomplete="off">
            </div>
            <div class="form-group">
              <label>Email</label>
              <input type="email" id="field_email" name="field_email" required="required" autocomplete="off">
            </div>
            <div class="form-group">
              <label>Nombre de Empresa</label>
              <input type="text" id="field_empresa" name="field_empresa" required="required" autocomplete="off">
            </div>
            <div class="form-group">
              <label>Teléfono</label>
              <input type="tel" id="field_teledono" name="field_telefono" required="required" autocomplete="off" placeholder="Ingrese sólo números">
            </div>
            <div class="form-group">
              <label>Selecciona Bodega</label>
              <select name="field_bodega" id="field_bodega">
                  <option value="opcion 1">opcion 1</option>
                  <option value="opcion 2">opcion 2</option>
                  <option value="opcion 3">opcion 3</option>
              </select>
            </div>
            <div class="form-submit">
              <button type="submit" class="btn_submit" id="btn_submit">COTIZA AQUÍ</button>
            </div>
            <a href="https://wa.me/+56999159535/?text=MensajedeContacto" target="_blank" class="boton_wsp"><img src="images/ic-buss.png" alt="" width="25"> +56 9 9915 9535</a>
          </form>
        </div>
    </div>